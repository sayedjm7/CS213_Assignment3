var hierarchy =
[
    [ "Board&lt; T &gt;", "class_board.html", null ],
    [ "Board&lt; char &gt;", "class_board.html", [
      [ "X_O_Board", "class_x___o___board.html", null ]
    ] ],
    [ "GameManager&lt; T &gt;", "class_game_manager.html", null ],
    [ "Move&lt; T &gt;", "class_move.html", null ],
    [ "Player&lt; T &gt;", "class_player.html", null ],
    [ "UI&lt; T &gt;", "class_u_i.html", null ],
    [ "UI&lt; char &gt;", "class_u_i.html", [
      [ "XO_UI", "class_x_o___u_i.html", null ]
    ] ]
];