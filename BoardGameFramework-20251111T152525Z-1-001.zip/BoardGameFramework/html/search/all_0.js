var searchData=
[
  ['board_0',['Board',['../class_board.html',1,'Board&lt; T &gt;'],['../class_board.html#ae5dfded241ee3644196e2f6074d1d0b1',1,'Board::Board(int rows, int columns)']]],
  ['board_1',['board',['../class_board.html#af00c1fc363eb640ca276b8a572040040',1,'Board']]],
  ['board_3c_20char_20_3e_2',['Board&lt; char &gt;',['../class_board.html',1,'']]],
  ['boardptr_3',['boardPtr',['../class_player.html#a26249e756f850b6585267bfbc928ac79',1,'Player']]]
];
