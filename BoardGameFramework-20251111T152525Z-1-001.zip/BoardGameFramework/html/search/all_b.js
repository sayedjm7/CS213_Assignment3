var searchData=
[
  ['ui_0',['UI',['../class_u_i.html',1,'UI&lt; T &gt;'],['../class_u_i.html#ae50eed41905ca2f8dc103d9bef427fe6',1,'UI::UI()']]],
  ['ui_3c_20char_20_3e_1',['UI&lt; char &gt;',['../class_u_i.html',1,'']]],
  ['update_5fboard_2',['update_board',['../class_board.html#a93d9dec601dda58b7e206ccb47633e57',1,'Board::update_board()'],['../class_x___o___board.html#aef2b0da670b2d5dc6333e0e0113f8b3d',1,'X_O_Board::update_board()']]]
];
