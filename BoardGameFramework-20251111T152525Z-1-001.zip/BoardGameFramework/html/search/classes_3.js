var searchData=
[
  ['player_0',['Player',['../class_player.html',1,'']]]
];
