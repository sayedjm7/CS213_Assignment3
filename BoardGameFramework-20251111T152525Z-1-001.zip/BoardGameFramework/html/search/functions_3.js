var searchData=
[
  ['game_5fis_5fover_0',['game_is_over',['../class_board.html#ae0e4575ec3cc4b6eb9f367ffb2beed13',1,'Board::game_is_over()'],['../class_x___o___board.html#aaee6e3efcbd685d9792d6d81356bba45',1,'X_O_Board::game_is_over()']]],
  ['gamemanager_1',['GameManager',['../class_game_manager.html#addaf3682d9783bdc432a8e3273b5b92c',1,'GameManager']]],
  ['get_5fboard_5fmatrix_2',['get_board_matrix',['../class_board.html#a117f2e61fdb7deccca333bbbc9c62d3a',1,'Board']]],
  ['get_5fboard_5fptr_3',['get_board_ptr',['../class_player.html#a508617eddfae8915d098102d480fc888',1,'Player']]],
  ['get_5fcolumns_4',['get_columns',['../class_board.html#ac665e1ed1f49125fab248e2c9ddfd608',1,'Board']]],
  ['get_5fmove_5',['get_move',['../class_u_i.html#a8befa259c38c57e6ae2e8ed81c476337',1,'UI::get_move()'],['../class_x_o___u_i.html#a4814913b14a2666667a2a90ab8205356',1,'XO_UI::get_move()']]],
  ['get_5fname_6',['get_name',['../class_player.html#aed2af19790ba73190e3ebeea589518e1',1,'Player']]],
  ['get_5fplayer_5fname_7',['get_player_name',['../class_u_i.html#a8617bbf64a9ddf11ea6231912044805d',1,'UI']]],
  ['get_5fplayer_5ftype_5fchoice_8',['get_player_type_choice',['../class_u_i.html#ae62d61367ea51a5d7532db3b830c6445',1,'UI']]],
  ['get_5frows_9',['get_rows',['../class_board.html#a93b130eff67bd4476fab27be8341cb78',1,'Board']]],
  ['get_5fsymbol_10',['get_symbol',['../class_move.html#a595bf740852c05a1cb425ef2640fd4ff',1,'Move::get_symbol()'],['../class_player.html#af56f0bf98c0423a3a75b0848607d03a4',1,'Player::get_symbol() const']]],
  ['get_5ftype_11',['get_type',['../class_player.html#a2df3bd299bf7aecfa2275ec6902a60f8',1,'Player']]],
  ['get_5fx_12',['get_x',['../class_move.html#a9d4f543a81e361f872d37bcfb64d5b55',1,'Move']]],
  ['get_5fy_13',['get_y',['../class_move.html#a96469802a55c9083a1e93c7edec8a00c',1,'Move']]]
];
