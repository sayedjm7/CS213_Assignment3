var searchData=
[
  ['cell_5fwidth_0',['cell_width',['../class_u_i.html#a6c79c489ae9aa3a7860fb58e5a14ddfe',1,'UI']]],
  ['columns_1',['columns',['../class_board.html#afaf8842d9d52ac724e8c2f5642ecafc7',1,'Board']]],
  ['create_5fplayer_2',['create_player',['../class_u_i.html#a94561e0bb4bbcbe5ff71ca6d751922df',1,'UI']]]
];
