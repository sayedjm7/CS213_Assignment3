var searchData=
[
  ['is_5fdraw_0',['is_draw',['../class_board.html#a8dbe2a243881986f3e53b45799d377fc',1,'Board::is_draw()'],['../class_x___o___board.html#a2be5f37643e21edbdea2361853a6e953',1,'X_O_Board::is_draw()']]],
  ['is_5flose_1',['is_lose',['../class_board.html#a207d5f6feb77f81c51d1462f0245890d',1,'Board::is_lose()'],['../class_x___o___board.html#aec0358cc4f109084267b953832478e94',1,'X_O_Board::is_lose()']]],
  ['is_5fwin_2',['is_win',['../class_board.html#ab316fe3e79677b4617fc3d90d6c48f33',1,'Board::is_win()'],['../class_x___o___board.html#aafb56a8db5bf8352157326a52c06e2e6',1,'X_O_Board::is_win()']]]
];
