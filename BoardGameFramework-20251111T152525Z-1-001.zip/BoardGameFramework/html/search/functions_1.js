var searchData=
[
  ['create_5fplayer_0',['create_player',['../class_u_i.html#a94561e0bb4bbcbe5ff71ca6d751922df',1,'UI']]]
];
