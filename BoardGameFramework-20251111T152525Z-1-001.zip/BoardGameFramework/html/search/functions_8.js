var searchData=
[
  ['set_5fboard_5fptr_0',['set_board_ptr',['../class_player.html#a3617a3ad0db435176a06948065f9a3a6',1,'Player']]],
  ['setup_5fplayers_1',['setup_players',['../class_u_i.html#a6966a040c995b2292e5edddaa94f889a',1,'UI']]]
];
