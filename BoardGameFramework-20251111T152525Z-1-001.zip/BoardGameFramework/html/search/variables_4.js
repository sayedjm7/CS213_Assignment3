var searchData=
[
  ['symbol_0',['symbol',['../class_player.html#a272d6c4dab769930d4f8074918e7708a',1,'Player']]]
];
