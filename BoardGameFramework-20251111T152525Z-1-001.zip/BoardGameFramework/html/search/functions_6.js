var searchData=
[
  ['player_0',['Player',['../class_player.html#adb4e803a7ac0356b111b8ca79d766976',1,'Player']]]
];
