var annotated_dup =
[
    [ "Board", "class_board.html", "class_board" ],
    [ "GameManager", "class_game_manager.html", "class_game_manager" ],
    [ "Move", "class_move.html", "class_move" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "UI", "class_u_i.html", "class_u_i" ],
    [ "X_O_Board", "class_x___o___board.html", "class_x___o___board" ],
    [ "XO_UI", "class_x_o___u_i.html", "class_x_o___u_i" ]
];