var class_u_i =
[
    [ "UI", "class_u_i.html#ae50eed41905ca2f8dc103d9bef427fe6", null ],
    [ "create_player", "class_u_i.html#a94561e0bb4bbcbe5ff71ca6d751922df", null ],
    [ "display_board_matrix", "class_u_i.html#a5d4655d5ff273e284fd68b8547483a23", null ],
    [ "display_message", "class_u_i.html#a1eead148ee8726b8ea329c2cd8841d18", null ],
    [ "get_move", "class_u_i.html#a8befa259c38c57e6ae2e8ed81c476337", null ],
    [ "get_player_name", "class_u_i.html#a8617bbf64a9ddf11ea6231912044805d", null ],
    [ "get_player_type_choice", "class_u_i.html#ae62d61367ea51a5d7532db3b830c6445", null ],
    [ "setup_players", "class_u_i.html#a6966a040c995b2292e5edddaa94f889a", null ],
    [ "cell_width", "class_u_i.html#a6c79c489ae9aa3a7860fb58e5a14ddfe", null ]
];