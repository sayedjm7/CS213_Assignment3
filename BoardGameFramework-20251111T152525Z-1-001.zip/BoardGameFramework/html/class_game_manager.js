var class_game_manager =
[
    [ "GameManager", "class_game_manager.html#addaf3682d9783bdc432a8e3273b5b92c", null ],
    [ "run", "class_game_manager.html#a71f46d5189dac5c773f608cea1b5a203", null ]
];